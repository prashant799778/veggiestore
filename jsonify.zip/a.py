d ='{"glasstypeId":"11","cof":"11"}'
a=d.replace("'",' ' )
print(a)